<!-- resources/views/tasks.blade.php -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Task Management System</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-lg-12">
                <h2>Task Management System</h2>
                <button class="btn btn-success mb-2" onclick="openModal()">Add Task</button>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Description</th>
                            <th>Status</th>
                            <th>Deadline</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="tasks">
                        <!-- Tasks will be displayed here -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Add Task Modal -->
    <div class="modal fade" id="taskModal" tabindex="-1" role="dialog" aria-labelledby="taskModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="taskModalLabel">Add Task</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="taskForm">
                        @csrf
                        <div class="form-group">
                            <label for="title">Title</label>
                            <input type="text" class="form-control" id="title" name="title" required>
                        </div>
                        <div class="form-group">
                            <label for="description">Description</label>
                            <textarea class="form-control" id="description" name="description"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="status">Status</label>
                            <select class="form-control" id="status" name="status" required>
                                <option value="pending">Pending</option>
                                <option value="completed">Completed</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="deadline">Deadline</label>
                            <input type="datetime-local" class="form-control" id="deadline" name="deadline">
                        </div>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Task Modal -->
    <div class="modal fade" id="editTaskModal" tabindex="-1" role="dialog" aria-labelledby="editTaskModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editTaskModalLabel">Edit Task</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="editTaskForm">
                        @csrf
                        @method('PUT')
                        <input type="hidden" id="editTaskId">
                        <div class="form-group">
                            <label for="editTitle">Title</label>
                            <input type="text" class="form-control" id="editTitle" name="title" required>
                        </div>
                        <div class="form-group">
                            <label for="editDescription">Description</label>
                            <textarea class="form-control" id="editDescription" name="description"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="editStatus">Status</label>
                            <select class="form-control" id="editStatus" name="status" required>
                                <option value="pending">Pending</option>
                                <option value="completed">Completed</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="editDeadline">Deadline</label>
                            <input type="datetime-local" class="form-control" id="editDeadline" name="deadline">
                        </div>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function() {
            getTasks();

            // Open Add Task Modal
            window.openModal = function() {
                $('#taskForm')[0].reset();
                $('#taskModal').modal('show');
            }

            // Save Task
            $('#taskForm').submit(function(e) {
                e.preventDefault();
                $.ajax({
                    type: 'POST',
                    url: '/api/tasks',
                    data: $(this).serialize(),
                    success: function(response) {
                        $('#taskModal').modal('hide');
                        getTasks();
                    },
                    error: function(error) {
                        console.log('Error:', error);
                    }
                });
            });

            // Open Edit Task Modal
            window.openEditModal = function(id) {
                $.get('/api/tasks/' + id, function(task) {
                    $('#editTaskId').val(task.id);
                    $('#editTitle').val(task.title);
                    $('#editDescription').val(task.description);
                    $('#editStatus').val(task.status);
                    $('#editDeadline').val(task.deadline.substring(0, 16)); // format: YYYY-MM-DDTHH:MM
                    $('#editTaskModal').modal('show');
                });
            }

            // Update Task
            $('#editTaskForm').submit(function(e) {
                e.preventDefault();
                var id = $('#editTaskId').val();
                $.ajax({
                    type: 'PUT',
                    url: '/api/tasks/' + id,
                    data: $(this).serialize(),
                    success: function(response) {
                        $('#editTaskModal').modal('hide');
                        getTasks();
                    },
                    error: function(error) {
                        console.log('Error:', error);
                    }
                });
            });

            // Delete Task
            window.deleteTask = function(id) {
                if (confirm('Are you sure you want to delete this task?')) {
                    $.ajax({
                        type: 'DELETE',
                        url: '/api/tasks/' + id,
                        success: function(response) {
                            getTasks();
                        },
                        error: function(error) {
                            console.log('Error:', error);
                        }
                    });
                }
            }

            // Get Tasks
            function getTasks() {
                $.get('/api/tasks', function(tasks) {
                    var rows = '';
                    tasks.forEach(function(task) {
                        rows += `
                            <tr>
                                <td>${task.title}</td>
                                <td>${task.description}</td>
                                <td>${task.status}</td>
                                <td>${task.deadline ? task.deadline.substring(0, 10) : ''}</td>
                                <td>
                                    <button class="btn btn-sm btn-primary" onclick="openEditModal(${task.id})">Edit</button>
                                    <button class="btn btn-sm btn-danger" onclick="deleteTask(${task.id})">Delete</button>
                                </td>
                            </tr>
                        `;
                    });
                    $('#tasks').html(rows);
                });
            }
        });
    </script>
</body>
</html>
