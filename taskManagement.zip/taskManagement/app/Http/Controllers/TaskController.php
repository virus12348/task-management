<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Task;

class TaskController extends Controller
{
    // Retrieve all tasks
    public function index()
    {
        return Task::all();
    }

    // Create a new task
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required',
            'description' => 'nullable',
            'status' => 'required|in:pending,completed',
            'deadline' => 'nullable|date'
        ]);

        return Task::create($request->all());
    }

    // Retrieve a specific task
    public function show($id)
    {
        return Task::findOrFail($id);
    }

    // Update a task
    public function update(Request $request, $id)
    {
        $request->validate([
            'title' => 'required',
            'description' => 'nullable',
            'status' => 'required|in:pending,completed',
            'deadline' => 'nullable|date'
        ]);

        $task = Task::findOrFail($id);
        $task->update($request->all());
        return $task;
    }

    // Delete a task
    public function destroy($id)
    {
        $task = Task::findOrFail($id);
        $task->delete();
        return 204;
    }
}
