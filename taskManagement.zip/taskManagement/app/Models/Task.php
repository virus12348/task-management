<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Task extends Model
{
    use HasFactory;

    protected $fillable = ['title', 'description', 'status', 'deadline'];

    protected $dates = ['deadline'];

    const STATUS_PENDING = 'pending';
    const STATUS_COMPLETED = 'completed';

    /**
     * Get the formatted deadline.
     *
     * @param  string  $value
     * @return string
     */
    public function getDeadlineAttribute($value)
    {
        return $value ? date('Y-m-d\TH:i', strtotime($value)) : null;
    }
}
