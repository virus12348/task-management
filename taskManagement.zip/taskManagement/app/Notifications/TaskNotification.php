<?php

namespace App\Notifications;

use App\Models\Task;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Notification;
use Illuminate\Notifications\Messages\MailMessage;

class TaskNotification extends Notification
{
    use Queueable;

    public $task;
    public $event;

    /**
     * Create a new notification instance.
     *
     * @param Task $task
     * @param string $event
     * @return void
     */
    public function __construct(Task $task, $event)
    {
        $this->task = $task;
        $this->event = $event;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        $subject = '';
        $message = '';

        if ($this->event == 'assigned') {
            $subject = 'New Task Assigned';
            $message = 'A new task has been assigned to you.';
        } elseif ($this->event == 'completed') {
            $subject = 'Task Completed';
            $message = 'The task has been marked as completed.';
        } elseif ($this->event == 'deadline_approaching') {
            $subject = 'Deadline Approaching';
            $message = 'The deadline for the task is approaching.';
        }

        return (new MailMessage)
                    ->subject($subject)
                    ->line($message)
                    ->action('View Task', url('/tasks/' . $this->task->id))
                    ->line('Thank you for using our application!');
    }
}
