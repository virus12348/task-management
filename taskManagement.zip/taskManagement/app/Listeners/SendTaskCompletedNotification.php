<?php

namespace App\Listeners;

use App\Events\TaskCompleted;
use App\Models\User;
use App\Notifications\TaskNotification;
use Illuminate\Contracts\Queue\ShouldQueue;

class SendTaskCompletedNotification implements ShouldQueue
{
    /**
     * Handle the event.
     *
     * @param  TaskCompleted  $event
     * @return void
     */
    public function handle(TaskCompleted $event)
    {
        $usersToNotify = User::all(); // Example: Notify all users
        foreach ($usersToNotify as $user) {
            $user->notify(new TaskNotification($event->task, 'completed'));
        }
    }
}
