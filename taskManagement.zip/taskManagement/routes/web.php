<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TaskController;

// // Define a route that supports the GET method
// Route::get('/tasks/{id}', [TaskController::class, 'show']);

// // Define a route that supports the PUT and DELETE methods
// Route::match(['put', 'delete'], '/tasks/{id}', [TaskController::class, 'update']);





// Route::get('/', function () {
//     return view('welcome');
// });
