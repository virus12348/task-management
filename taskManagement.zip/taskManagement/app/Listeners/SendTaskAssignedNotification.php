<?php

namespace App\Listeners;

use App\Events\TaskAssigned;
use App\Models\User;
use App\Notifications\TaskNotification;
use Illuminate\Contracts\Queue\ShouldQueue;

class SendTaskAssignedNotification implements ShouldQueue
{
    /**
     * Handle the event.
     *
     * @param  TaskAssigned  $event
     * @return void
     */
    public function handle(TaskAssigned $event)
    {
        $usersToNotify = User::all(); // Example: Notify all users
        foreach ($usersToNotify as $user) {
            $user->notify(new TaskNotification($event->task, 'assigned'));
        }
    }
}
