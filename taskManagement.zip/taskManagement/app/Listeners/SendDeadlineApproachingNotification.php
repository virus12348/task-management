<?php

namespace App\Listeners;

use App\Events\DeadlineApproaching;
use App\Models\User;
use App\Notifications\TaskNotification;
use Illuminate\Contracts\Queue\ShouldQueue;

class SendDeadlineApproachingNotification implements ShouldQueue
{
    /**
     * Handle the event.
     *
     * @param  DeadlineApproaching  $event
     * @return void
     */
    public function handle(DeadlineApproaching $event)
    {
        $usersToNotify = User::all(); // Example: Notify all users
        foreach ($usersToNotify as $user) {
            $user->notify(new TaskNotification($event->task, 'deadline_approaching'));
        }
    }
}
